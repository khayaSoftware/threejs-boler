# Three.js basic scene boilerplate

A Pen created on CodePen.io. Original URL: [https://codepen.io/michellebarker/pen/gORxyMB](https://codepen.io/michellebarker/pen/gORxyMB).

